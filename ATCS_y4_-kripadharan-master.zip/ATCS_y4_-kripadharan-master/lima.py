
__author__ = 'Kripa Dharan'


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score, recall_score
from sklearn.linear_model import Perceptron

iris_data = pd.read_csv("iris_data.csv" )
titanic_train = pd.read_csv("titanic_train2.csv")
titanic_test = pd.read_csv("titanic_test2.csv")


def print_conf_matrix(targets, outputs):
    cm = confusion_matrix(targets, outputs)
    print("Confusion Matrix:")
    print("     PN PP")
    print("AN: "+ str(cm[0]))
    print("AP: "+ str(cm[1]))

#Function to classify a certain type of flower based on specific inputs
def classify(flower, inputs):
	def class_to_targets(target):
		if target == flower:
			return 1
		else:
			return 0
	iris_inputs = iris_data[inputs]
	iris_targets = iris_targets = iris_data['class'].apply(class_to_targets)

	percey = Perceptron()

	print("Training a Perceptron to classify " + flower + " using " + str(inputs))
	percey.fit(iris_inputs, iris_targets)
	percey_outputs = percey.predict(iris_inputs)

	print("Found weights=" + str(percey.coef_) + " and threshold: " + str(percey.intercept_) + " in " + str(percey.n_iter_) + " epochs.")
	print_conf_matrix(iris_targets, percey_outputs)
	print("Precision = TP / (TP + FP) = ", precision_score(iris_targets, percey_outputs))
	print("Recall = TP / (TP + FN) = ", recall_score(iris_targets, percey_outputs))

classify("Iris-setosa", ['petal width', 'petal length'])
classify("Iris-virginica", ['sepal width', 'sepal length'])
classify("Iris-virginica", ['petal width', 'petal length'])
classify("Iris-virginica", ['petal width', 'petal length', 'sepal length', 'sepal width'])


def gender_to_type(sex):
	if sex == 'female':
		return 1
	else:
		return 0
titanic_train['gender'] = titanic_train['Sex'].apply(gender_to_type)


print("Titanic Survivor Classification")
percey = Perceptron(n_iter_no_change=20)
titanic_inputs = titanic_train[['gender', 'Pclass']]

#I tried a lot of other imput combinations, and this one turned out to the best one I came across
print("Inputs Used: gender, pclass")

titanic_targets = titanic_train['Survived']
percey.fit(titanic_inputs, titanic_targets)
titanic_outputs = percey.predict(titanic_inputs)
print("Results for Training Data")
print("Found weights=" + str(percey.coef_) + " and threshold: " + str(percey.intercept_) + " in " + str(percey.n_iter_) + " epochs.")
print_conf_matrix(titanic_targets, titanic_outputs)
print("Precision = TP / (TP + FP) = ", precision_score(titanic_targets, titanic_outputs))
print("Recall = TP / (TP + FN) = ", recall_score(titanic_targets, titanic_outputs))
print("Mean accuracy: ", percey.score(titanic_inputs, titanic_targets))



titanic_test['gender'] = titanic_test['Sex'].apply(gender_to_type)

test_inputs = titanic_test[['gender', 'Pclass']]
test_predictions = percey.predict(test_inputs)
test_targets = titanic_test['Survived']

print("Results for Test Data")
print_conf_matrix(test_targets, test_predictions)
print("Precision = TP / (TP + FP) = ", precision_score(test_targets, test_predictions))
print("Recall = TP / (TP + FN) = ", recall_score(test_targets, test_predictions))
print("Mean accuracy: ", percey.score(test_inputs, test_targets))



